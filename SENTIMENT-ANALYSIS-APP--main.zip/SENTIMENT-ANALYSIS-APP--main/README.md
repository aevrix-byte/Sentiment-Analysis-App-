# Sentiment Analysis Web App

**Live Demo:** [https://sentiment-analysis-app-omega.vercel.app/](https://sentiment-analysis-app-omega.vercel.app/)

An AI-powered web application that classifies user-entered text as **Positive**, **Negative**, or **Neutral** in real-time. The application utilizes a trained Naïve Bayes classifier built entirely in Python using `scikit-learn` and deployed seamlessly via a Flask API backend. 

## Features
- **Machine Learning Analysis:** Built atop a powerful Naïve Bayes pipeline utilizing TF-IDF vectorization. 
- **Modern UI/UX:** A sleek, glass-morphism designed frontend written in pure HTML, CSS, and dynamic JavaScript.
- **Micro-Animations:** Beautiful state transitions, glowing dynamic backgrounds, and confidence percentage bars.
- **RESTful API:** Predicts text sentiment probabilities on-the-fly without page reloads.

## Tech Stack
- **Python** | **Scikit-learn** | **Flask**
- **HTML5** | **CSS3** | **Vanilla JavaScript**

## Application Overview
This application uses a custom-trained machine learning model leveraging a Naïve Bayes algorithm. The model analyzes review-style sentiment and dynamically calculates live probabilities. 

The entire backend is strictly written as Vercel-compatible serverless functions.

## Cloud Deployment (Vercel)
This project is configured perfectly for Vercel Serverless Functions. 
The repository includes a customized `vercel.json` file which automatically converts the Python Flask instance (`app.py`) into an active cloud microservice.

To redeploy, simply:
1. Push any local changes to the `main` branch.
2. Vercel's automatic CI/CD pipeline will seamlessly handle the `requirements.txt` installation and natively launch the API.
