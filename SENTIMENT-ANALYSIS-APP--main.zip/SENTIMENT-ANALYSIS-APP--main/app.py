from flask import Flask, request, jsonify, render_template
import joblib
import os

app = Flask(__name__)

# Load model and vectorizer
MODEL_PATH = os.path.join('model', 'sentiment_pipeline.pkl')

# Global variable for the pipeline
pipeline = None

def load_model():
    global pipeline
    if os.path.exists(MODEL_PATH):
        pipeline = joblib.load(MODEL_PATH)

@app.before_request
def before_request():
    if pipeline is None:
        load_model()

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    if not pipeline:
        return jsonify({'error': 'Model not trained yet. Please run train_model.py first.', 'sentiment': 'Neutral', 'confidence': 0.0})
    
    data = request.get_json()
    text = data.get('text', '')
    
    if not text:
        return jsonify({'error': 'No text provided'})
        
    try:
        prediction = pipeline.predict([text])[0]
        # predict_proba returns a 2D array, we get the first row
        probabilities = pipeline.predict_proba([text])[0]
        confidence = max(probabilities) * 100
        
        sentiment = str(prediction)
        
        return jsonify({
            'sentiment': sentiment,
            'confidence': round(confidence, 2)
        })
    except Exception as e:
        return jsonify({'error': str(e), 'sentiment': 'Neutral', 'confidence': 0.0})

if __name__ == '__main__':
    load_model()
    app.run(debug=True, port=5000)
