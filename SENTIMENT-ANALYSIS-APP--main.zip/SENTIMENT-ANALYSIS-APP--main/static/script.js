document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('sentiment-form');
    const analyzeBtn = document.getElementById('analyze-btn');
    const btnText = analyzeBtn.querySelector('.btn-text');
    const loader = analyzeBtn.querySelector('.loader');
    
    const resultContainer = document.getElementById('result-container');
    const resultCard = document.querySelector('.result-card');
    const sentimentIcon = document.getElementById('sentiment-icon');
    const sentimentLabel = document.getElementById('sentiment-label');
    const confidenceBar = document.getElementById('confidence-bar');
    const confidenceText = document.getElementById('confidence-text');

    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const text = document.getElementById('review-text').value.trim();
        if (!text) return;

        // UI Loading state - show spinner, disable button
        btnText.classList.add('hidden');
        loader.classList.remove('hidden');
        analyzeBtn.disabled = true;
        
        // Hide previous results to re-animate
        resultContainer.classList.add('hidden');
        resultCard.className = 'result-card'; // Strip out color classes
        confidenceBar.style.width = '0%'; // Reset bar

        try {
            // Fetch prediction from REST backend
            const response = await fetch('/predict', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ text })
            });

            const data = await response.json();
            
            if (data.error && data.sentiment === 'Neutral' && data.confidence === 0) {
                alert(`Backend Error: ${data.error}`);
            }

            // Display results smoothly
            displayResult(data.sentiment, data.confidence);
            
        } catch (error) {
            console.error('Error:', error);
            alert('Failed to connect to the server. Make sure the Flask backend is running.');
        } finally {
            // Restore button UI
            btnText.classList.remove('hidden');
            loader.classList.add('hidden');
            analyzeBtn.disabled = false;
        }
    });

    function displayResult(sentiment, confidence) {
        // Show result box
        resultContainer.classList.remove('hidden');
        
        // Setup Icon and Label based on received sentiment
        let icon = '';
        if (sentiment.toLowerCase() === 'positive') {
            resultCard.classList.add('is-positive');
            icon = '😊';
        } else if (sentiment.toLowerCase() === 'negative') {
            resultCard.classList.add('is-negative');
            icon = '😞';
        } else {
            resultCard.classList.add('is-neutral');
            icon = '😐';
        }

        // Apply DOM updates
        sentimentIcon.textContent = icon;
        sentimentLabel.textContent = sentiment;
        confidenceText.textContent = `${confidence}% Confidence`;
        
        // Delay width assignment slightly to trigger CSS transition animation
        setTimeout(() => {
            confidenceBar.style.width = `${confidence}%`;
        }, 50);
    }
});
