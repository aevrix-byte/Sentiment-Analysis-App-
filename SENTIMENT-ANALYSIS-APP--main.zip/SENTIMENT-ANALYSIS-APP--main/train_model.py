import os
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import make_pipeline
import joblib

def train_dummy_model():
    print("Training Naïve Bayes model for Sentiment Analysis on sample data...")
    # Dummy data to represent the IMDb functionality
    # In a real scenario with full ~85% accuracy IMDb dataset, you would load the massive CSV here.
    data = {
        'review': [
            'Absolutely wonderful! I loved it, great acting.', 
            'Terrible movie, absolute waste of time.', 
            'It was okay, nothing special to write home about.',
            'Best film of the year! The cinematography is stunning.',
            'I hated this. So boring and poorly directed.',
            'A true masterpiece of cinema.',
            'Not my cup of tea. Very bland.',
            'Fantastic acting and great story.',
            'Awful plot and terrible acting all around.',
            'It was decent, I guess. Could have been better.',
            'I enjoyed every second of it!',
            'Worst experience of my life.'
        ],
        'sentiment': ['Positive', 'Negative', 'Neutral', 'Positive', 'Negative', 'Positive', 'Negative', 'Positive', 'Negative', 'Neutral', 'Positive', 'Negative']
    }
    df = pd.DataFrame(data)
    
    # Text vectorization & Naive Bayes classifier via Pipeline
    pipeline = make_pipeline(
        TfidfVectorizer(stop_words='english'),
        MultinomialNB()
    )
    
    # Train the model
    pipeline.fit(df['review'], df['sentiment'])
    
    # Ensure dir exists and save
    os.makedirs('model', exist_ok=True)
    joblib.dump(pipeline, 'model/sentiment_pipeline.pkl')
    print("Model successfully trained and saved to model/sentiment_pipeline.pkl")
    
    print("\n--- IMDB DATASET INSTRUCTIONS ---")
    print("To train on the real IMDB dataset to achieve ~85% accuracy:")
    print("1. Download the IMDB dataset (e.g. IMDB Dataset of 50K Movie Reviews)")
    print("2. Code:")
    print("   df = pd.read_csv('IMDB Dataset.csv')")
    print("   # Map positive -> Positive, negative -> Negative")
    print("   df['sentiment'] = df['sentiment'].str.capitalize()")
    print("   pipeline.fit(df['review'], df['sentiment'])")
    print("   joblib.dump(pipeline, 'model/sentiment_pipeline.pkl')")

if __name__ == "__main__":
    train_dummy_model()
